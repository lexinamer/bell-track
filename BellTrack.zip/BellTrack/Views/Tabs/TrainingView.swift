import SwiftUI

struct TrainingView: View {

    @StateObject private var blocksVM = BlocksViewModel()

    // Navigation
    @State private var selectedBlock: Block?

    // Sheets
    @State private var showingNewBlock = false
    @State private var showingNewWorkout = false
    @State private var editingBlock: Block?
    @State private var blockToDelete: Block?

    // MARK: - Derived

    private var activeBlocks: [Block] {
        blocksVM.blocks
            .filter {
                $0.completedDate == nil &&
                $0.startDate <= Date()
            }
            .sorted { $0.startDate > $1.startDate }
    }

    private var futureBlocks: [Block] {
        blocksVM.blocks
            .filter {
                $0.completedDate == nil &&
                $0.startDate > Date()
            }
            .sorted { $0.startDate < $1.startDate }
    }

    private var completedBlocks: [Block] {
        blocksVM.blocks
            .filter { $0.completedDate != nil }
            .sorted {
                ($0.completedDate ?? .distantPast)
                >
                ($1.completedDate ?? .distantPast)
            }
    }

    // MARK: - View

    var body: some View {

        ZStack {

            Color.brand.background
                .ignoresSafeArea()

            if blocksVM.isLoading && blocksVM.blocks.isEmpty {

                ProgressView()

            } else if blocksVM.blocks.isEmpty {

                emptyState

            } else {

                ScrollView {

                    LazyVStack(
                        alignment: .leading,
                        spacing: Theme.Space.xl
                    ) {

                        if !activeBlocks.isEmpty {
                            section(
                                title: "Active",
                                blocks: activeBlocks
                            )
                        }

                        if !futureBlocks.isEmpty {
                            section(
                                title: "Planned",
                                blocks: futureBlocks
                            )
                        }

                        if !completedBlocks.isEmpty {
                            section(
                                title: "Completed",
                                blocks: completedBlocks
                            )
                        }
                    }
                    .padding(.vertical)
                }
            }
        }
        .navigationTitle("Training")

        // MARK: - Toolbar

        .toolbar {

            ToolbarItem(placement: .topBarTrailing) {

                HStack(spacing: Theme.Space.xs) {

                    Button {
                        showingNewWorkout = true
                    } label: {
                        Image(systemName: "figure.run")
                    }

                    Button {
                        showingNewBlock = true
                    } label: {
                        Image(systemName: "plus")
                    }
                }
            }
        }

        // MARK: - Navigation

        .navigationDestination(item: $selectedBlock) {
            BlockDetailView(block: $0, blocksVM: blocksVM)
        }

        // MARK: - New Block Sheet

        .fullScreenCover(isPresented: $showingNewBlock) {

            BlockFormView(
                blocksVM: blocksVM,
                onSave: { name, start, type, duration, notes, color, pendingTemplates in

                    Task {

                        await blocksVM.saveBlock(
                            id: nil,
                            name: name,
                            startDate: start,
                            type: type,
                            durationWeeks: duration,
                            notes: notes,
                            colorIndex: color,
                            pendingTemplates: pendingTemplates
                        )

                        showingNewBlock = false
                    }
                },
                onCancel: {
                    showingNewBlock = false
                }
            )
        }

        // MARK: - Edit Block Sheet

        .fullScreenCover(item: $editingBlock) { block in

            BlockFormView(
                block: block,
                blocksVM: blocksVM,
                onSave: { name, startDate, type, durationWeeks, notes, colorIndex, _ in
                    Task {
                        await blocksVM.saveBlock(
                            id: block.id,
                            name: name,
                            startDate: startDate,
                            type: type,
                            durationWeeks: durationWeeks,
                            notes: notes,
                            colorIndex: colorIndex
                        )
                        editingBlock = nil
                    }
                },
                onCancel: {
                    editingBlock = nil
                }
            )
        }

        // MARK: - New Workout Sheet

        .fullScreenCover(isPresented: $showingNewWorkout) {

            WorkoutFormView(
                workout: nil,
                onSave: {
                    showingNewWorkout = false
                    Task { await blocksVM.load() }
                },
                onCancel: {
                    showingNewWorkout = false
                }
            )
        }

        // MARK: - Delete Block Alert

        .alert(
            "Delete Block?",
            isPresented: deleteBlockBinding
        ) {
            Button("Cancel", role: .cancel) {}
            Button("Delete", role: .destructive) {
                if let block = blockToDelete {
                    Task {
                        await blocksVM.deleteBlock(id: block.id)
                    }
                }
            }
        } message: {
            Text(
                "This will permanently delete \"\(blockToDelete?.name ?? "")\"."
            )
        }

        // MARK: - Load

        .task {
            await blocksVM.load()
        }
    }

    // MARK: - Section

    private func section(
        title: String,
        blocks: [Block]
    ) -> some View {
        VStack(alignment: .leading, spacing: Theme.Space.sm) {
            Text(title)
                .font(Theme.Font.sectionTitle)
                .padding(.horizontal)
            LazyVStack(spacing: Theme.Space.sm) {
                ForEach(blocks) { block in
                    BlockCard(
                        block: block,
                        workoutCount: blocksVM.workoutCounts[block.id],
                        templateCount: blocksVM.templatesForBlock(block.id).count,
                        onEdit: {
                            editingBlock = block
                        },
                        onComplete: {
                            Task {
                                await blocksVM.completeBlock(id: block.id)
                            }
                        },
                        onDelete: {
                            blockToDelete = block
                        }
                    )
                    .padding(.horizontal)
                    .onTapGesture {
                        selectedBlock = block
                    }
                }
            }
        }
    }

    // MARK: - Empty State

    private var emptyState: some View {

        VStack(spacing: Theme.Space.lg) {

            Spacer()

            Image(systemName: "figure.strengthtraining.traditional")
                .font(.system(size: 44))
                .foregroundColor(.secondary)

            Text("Start your training")
                .font(Theme.Font.emptyStateTitle)

            Text("Create a block to organize your training, then log workouts.")
                .font(Theme.Font.emptyStateDescription)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, Theme.Space.lg)

            Button {
                showingNewBlock = true
            } label: {

                Text("Create Block")
                    .font(Theme.Font.buttonPrimary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, Theme.Space.sm)
                    .background(Color.brand.primary)
                    .foregroundColor(.white)
                    .cornerRadius(Theme.Radius.md)
            }
            .padding(.horizontal, Theme.Space.xl)

            Spacer()
        }
    }

    // MARK: - Binding

    private var deleteBlockBinding: Binding<Bool> {
        Binding(
            get: { blockToDelete != nil },
            set: {
                if !$0 {
                    blockToDelete = nil
                }
            }
        )
    }
}
